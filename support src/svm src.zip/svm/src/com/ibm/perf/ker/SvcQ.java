package com.ibm.perf.ker;

import com.ibm.perf.parameter.Parameter;
import com.ibm.perf.parameter.Data;
import com.ibm.perf.svm.Cache;



//
//Q matrices for various formulations
//
/**Ϊ֧������������ĺ˾���ľ���ʵ��*/
public class SvcQ extends Kernel
{
	private final byte[] y;
	private final Cache cache;
	private final double[] QD;

	public SvcQ(Data prob, Parameter param, byte[] y_)
	{
		super(prob.l, prob.x, param);
		y = (byte[])y_.clone();
		//��byte-KB(1<<10��-MB(1<<20)
		cache = new Cache(prob.l,(long)(param.cacheSize*(1<<20)));
		QD = new double[prob.l];
		for(int i=0;i<prob.l;i++)
			QD[i] = kernelFunction(i,i);
	}

	public float[] getQ(int i, int len)
	{
		float[][] data = new float[1][];
		int start, j;
		if((start = cache.getData(i,data,len)) < len)
		{
			for(j=start;j<len;j++)
				data[0][j] = (float)(y[i]*y[j]*kernelFunction(i,j));
		}
		return data[0];
	}

	public double[] getQD()
	{
		return QD;
	}
	
	public void swapIndex(int i, int j)
	{    
		cache.swapIndex(i,j);
		//x[i],x[j]��x_square[i]��x_square[j]������
		super.swapIndex(i,j);
		do {byte _=y[i]; y[i]=y[j]; y[j]=_;} while(false);
		do {double _=QD[i]; QD[i]=QD[j]; QD[j]=_;} while(false);
	}
}