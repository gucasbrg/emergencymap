package com.ibm.perf.svm;



import java.util.Random;

import com.ibm.perf.ker.Kernel;
import com.ibm.perf.parameter.PrintInterface;
import com.ibm.perf.parameter.Model;
import com.ibm.perf.parameter.Node;
import com.ibm.perf.parameter.Parameter;
import com.ibm.perf.parameter.Data;
import com.ibm.perf.sol.Solution;
import com.ibm.perf.sol.SolutionInfo;



/**	������Ϊ��������м��࣬Ʃ�緵�ؾ��ߺ���ģ�ͣ����صĲ������õ��ķ���ϵ����  
        ��������֤�ȵȻ����������ڴ�����*/
public class Predict {
	//
	// construct and solve various formulations
	//
	public static final int VERSION=01; 
	public static final Random rand = new Random();

	private static PrintInterface svm_print_stdout = new PrintInterface()
	{
		public void print(String s)
		{
			System.out.print(s);
			System.out.flush();
		}
	};

	private static PrintInterface svm_print_string = svm_print_stdout;

	public static void info(String s) 
	{
		svm_print_string.print(s);
	}

	
	 /**decision_function
	alphaʵ��Ϊϵ����alpha[i]*y[i]*/
	static class decisionCoefficient
	{
		double[] alpha;
		double rho;	
	};
     /**���ؾ��ߺ���
     * @param data  ���ݼ�
	 * @param param ����
	 * @param Cp    ��<sub>i</sub>���Ͻ� for y<sub>i</sub> = 1
	 * @param Cn    ��<sub>i</sub>���Ͻ� for y<sub>i</sub> =-1
	 */
	static decisionCoefficient svmDecisionFunction(Data data,
			Parameter param, double Cp, double Cn)	{
		double[] alpha = new double[data.l];
		SolutionInfo si = new SolutionInfo();
		switch(param.svmType)
		{
			case Parameter.C_SVC:
				Solution.solveC_svc(data,param,alpha,si,Cp,Cn);
				break;
			case Parameter.NU_SVC:
				Solution.solveNu_svc(data,param,alpha,si);
				break;
			case Parameter.EPSILON_SVR:
				Solution.solveEpsilon_svr(data,param,alpha,si);
				break;
			case Parameter.NU_SVR:
				Solution.solveNu_svr(data,param,alpha,si);
				break;
		}

		Predict.info("Ŀ��ֵ = "+si.obj+", ϵ��b���෴��= "+si.rho+"\n");

		// output SVs

		int nSV = 0;
		int nBSV = 0;
		for(int i=0;i<data.l;i++)
		{
			if(Math.abs(alpha[i]) > 0)
			{
				++nSV;
				if(data.y[i] > 0)
				{
					if(Math.abs(alpha[i]) >= si.upper_bound_p)
					++nBSV;
				}
				else
				{
					if(Math.abs(alpha[i]) >= si.upper_bound_n)
						++nBSV;
				}
			}
		}

		Predict.info("֧������ = "+nSV+", �ﵽ�߽��֧������ = "+nBSV+"\n");

		decisionCoefficient f = new decisionCoefficient();
		f.alpha = alpha;
		f.rho = si.rho;
		return f;
	}


	/** ���з�������
      * @param data  ���ݼ�
      * @param nr_class_ret set of classes 
      * @param label_ret label name
      * @param start_ret begin of each class
      * @param count_ret data of classes
      * @param perm indices to the original data
	*/
	public static void svmGroupClasses(Data data, int[] nr_class_ret, int[][] label_ret, int[][] start_ret, int[][] count_ret, int[] perm)
	{
		int l = data.l;
		int max_nr_class = 16;
		int nr_class = 0;
		int[] label = new int[max_nr_class];
		int[] count = new int[max_nr_class];
		int[] data_label = new int[l];
		int i;

		for(i=0;i<l;i++)
		{
			int this_label = (int)(data.y[i]);
			int j;
			for(j=0;j<nr_class;j++)
			{
				if(this_label == label[j])
				{
					++count[j];
					break;
				}
			}
			data_label[i] = j;
			if(j == nr_class)
			{
				if(nr_class == max_nr_class)
				{
					max_nr_class *= 2;
					int[] new_data = new int[max_nr_class];
					System.arraycopy(label,0,new_data,0,label.length);
					label = new_data;
					new_data = new int[max_nr_class];
					System.arraycopy(count,0,new_data,0,count.length);
					count = new_data;					
				}
				label[nr_class] = this_label;
				count[nr_class] = 1;
				++nr_class;
			}
		}

		int[] start = new int[nr_class];
		start[0] = 0;
		for(i=1;i<nr_class;i++)
			start[i] = start[i-1]+count[i-1];
		for(i=0;i<l;i++)
		{
			perm[start[data_label[i]]] = i;
			++start[data_label[i]];
		}
		start[0] = 0;
		for(i=1;i<nr_class;i++)
			start[i] = start[i-1]+count[i-1];

		nr_class_ret[0] = nr_class;
		label_ret[0] = label;
		start_ret[0] = start;
		count_ret[0] = count;
	}

	
	/**�÷�������һ��ѵ���õ�Model
	 * @param data ѵ������
	 * @param param ѵ������*/
	public static Model svmTrain(Data data, Parameter param)
	{
		Model model = new Model();
		model.param = param;

		if(param.svmType == Parameter.EPSILON_SVR ||
		   param.svmType == Parameter.NU_SVR)
		{
			// �ع��-svm
			model.categoryNumber = 2;
			model.label = null;
			model.nSV = null;
			model.svCoef = new double[1][];


			decisionCoefficient f = svmDecisionFunction(data,param,0,0);
			model.rho = new double[1];
			model.rho[0] = f.rho;

			int nSV = 0;
			int i;
			for(i=0;i<data.l;i++)
				if(Math.abs(f.alpha[i]) > 0) ++nSV;
			model.svNumber = nSV;
			model.SV = new Node[nSV][];
			model.svCoef[0] = new double[nSV];
			int j = 0;
			for(i=0;i<data.l;i++)
				if(Math.abs(f.alpha[i]) > 0)
				{
					model.SV[j] = data.x[i];
					model.svCoef[0][j] = f.alpha[i];
					++j;
				}
		}
		else
		{
			// classification
			int l = data.l;
			int[] tmp_nr_class = new int[1];
			int[][] tmp_label = new int[1][];
			int[][] tmp_start = new int[1][];
			int[][] tmp_count = new int[1][];			
			int[] perm = new int[l];

			// group training data of the same class
			svmGroupClasses(data,tmp_nr_class,tmp_label,tmp_start,tmp_count,perm);
			int nr_class = tmp_nr_class[0];			
			int[] label = tmp_label[0];
			int[] start = tmp_start[0];
			int[] count = tmp_count[0];
 			
			if(nr_class == 1) 
				Predict.info("WARNING: training data in only one class. See README for details.\n");
			
			Node[][] x = new Node[l][];
			int i;
			for(i=0;i<l;i++)
				x[i] = data.x[perm[i]];

			// calculate weighted C

			double[] weighted_C = new double[nr_class];
			for(i=0;i<nr_class;i++)
				weighted_C[i] = param.C;
		    //for C-SVC ��ʹ�ò�ͬ�ͷ������ӵ��������û�п���Ϊ0
			for(i=0;i<param.nr_weight;i++)
			{
				int j;
				for(j=0;j<nr_class;j++)
					if(param.weight_label[i] == label[j])
						break;
				if(j == nr_class)
					System.err.print("WARNING: class label "+param.weight_label[i]+" specified in weight is not found\n");
				else
					weighted_C[j] *= param.weight[i];
			}

			// train k*(k-1)/2 models ѵ����������ģ��

			boolean[] nonzero = new boolean[l];
			for(i=0;i<l;i++)
				nonzero[i] = false;
			decisionCoefficient[] f = new decisionCoefficient[nr_class*(nr_class-1)/2];

			int p = 0;
			for(i=0;i<nr_class;i++)
				for(int j=i+1;j<nr_class;j++)
				{
					Data sub_prob = new Data();
					/*begin   
					 svm_binary_svc_probability
					 * dec_values[perm[j]]=dec_value[0];
					// ensure +1 -1 order; reason not using CV subroutine
					   dec_values[perm[j]] *= submodel.label[0];               
					   ����[i]��ֵΪ+1��[j]��ֵΪ-1����ʵ���п��������෴  */
					int si = start[i], sj = start[j];
					int ci = count[i], cj = count[j];
					sub_prob.l = ci+cj;
					sub_prob.x = new Node[sub_prob.l][];
					sub_prob.y = new double[sub_prob.l];
					int k;
					for(k=0;k<ci;k++)
					{
						sub_prob.x[k] = x[si+k];
						sub_prob.y[k] = +1;
					}
					for(k=0;k<cj;k++)
					{
						sub_prob.x[ci+k] = x[sj+k];
						sub_prob.y[ci+k] = -1;
					}
					/*end      */				

					f[p] = svmDecisionFunction(sub_prob,param,weighted_C[i],weighted_C[j]);
					for(k=0;k<ci;k++)
						if(!nonzero[si+k] && Math.abs(f[p].alpha[k]) > 0)
							nonzero[si+k] = true;
					for(k=0;k<cj;k++)
						if(!nonzero[sj+k] && Math.abs(f[p].alpha[ci+k]) > 0)
							nonzero[sj+k] = true;
					++p;   //p=nr_class*(nr_class-1)/2
				}

			// build output

			model.categoryNumber = nr_class;

			model.label = new int[nr_class];
			for(i=0;i<nr_class;i++)
				model.label[i] = label[i];

			model.rho = new double[nr_class*(nr_class-1)/2];
			for(i=0;i<nr_class*(nr_class-1)/2;i++)
				model.rho[i] = f[i].rho;
			int nnz = 0;
			int[] nz_count = new int[nr_class];
			model.nSV = new int[nr_class];
			for(i=0;i<nr_class;i++)
			{
				int nSV = 0;
				for(int j=0;j<count[i];j++)
					if(nonzero[start[i]+j])
					{
						++nSV;
						++nnz;
					}
				model.nSV[i] = nSV;
				nz_count[i] = nSV;
			}

			Predict.info("�ܵ�֧������= "+nnz+"\n");

			model.svNumber = nnz;
			model.SV = new Node[nnz][];
			p = 0;
			for(i=0;i<l;i++)
				if(nonzero[i]) model.SV[p++] = x[i];

			int[] nz_start = new int[nr_class];
			nz_start[0] = 0;
			for(i=1;i<nr_class;i++)
				nz_start[i] = nz_start[i-1]+nz_count[i-1];

			model.svCoef = new double[nr_class-1][];
			for(i=0;i<nr_class-1;i++)
				model.svCoef[i] = new double[nnz];

			p = 0;
			for(i=0;i<nr_class;i++)
				for(int j=i+1;j<nr_class;j++)
				{
					// classifier (i,j): coefficients with
					// i are in sv_coef[j-1][nz_start[i]...],
					// j are in sv_coef[i][nz_start[j]...]

					int si = start[i];
					int sj = start[j];
					int ci = count[i];
					int cj = count[j];

					int q = nz_start[i];
					int k;
					for(k=0;k<ci;k++)
						if(nonzero[si+k])
							model.svCoef[j-1][q++] = f[p].alpha[k];
					q = nz_start[j];
					for(k=0;k<cj;k++)
						if(nonzero[sj+k])
							model.svCoef[i][q++] = f[p].alpha[ci+k];
					++p;
				}
		}
		return model;
	}
	
	/**��SVM��������֤ 
	*@param data ������ķ������⣬�����������ݡ�
	*@param param ѵ��������
	*@param nr_fold ����˼�����k�۽�����֤�е�k�����k=n�Ļ�������һ���ˡ�
	*@param target Ԥ��ֵ������Ƿ�������Ļ���������ǩ�ˣ�Ԥ�������ǩ*/
	public static  void svmCrossValidation(Data data, Parameter param, int nr_fold, double[] target)
	{
		int i;
		int[] fold_start = new int[nr_fold+1];
		int l= data.l;
		int[] perm = new int[l];
		
		// stratified cv may not give leave-one-out rate
		// Each class to l folds -> some folds may have zero elements
		if((param.svmType == Parameter.C_SVC ||
		    param.svmType == Parameter.NU_SVC) && nr_fold < l)
		{
			int[] tmp_nr_class = new int[1];
			int[][] tmp_label = new int[1][];
			int[][] tmp_start = new int[1][];
			int[][] tmp_count = new int[1][];

			svmGroupClasses(data,tmp_nr_class,tmp_label,tmp_start,tmp_count,perm);

			int nr_class = tmp_nr_class[0];
			int[] start = tmp_start[0];
			int[] count = tmp_count[0];		

			// random shuffle and then data grouped by fold using the array perm
			//���ϴ��
			int[] fold_count = new int[nr_fold];
			int c;
			int[] index = new int[l];
			for(i=0;i<l;i++)
				index[i]=perm[i];
			for (c=0; c<nr_class; c++)
				for(i=0;i<count[c];i++)
				{
					int j = i+rand.nextInt(count[c]-i);
					do {int _=index[start[c]+j]; index[start[c]+j]=index[start[c]+i]; index[start[c]+i]=_;} while(false);
				}
			for(i=0;i<nr_fold;i++)
			{
				fold_count[i] = 0;
			   //count[i]�������label[i]��ĸ�����fold_count[i]��ʾ��i�۵ĸ���
				for (c=0; c<nr_class;c++)
					fold_count[i]+=(i+1)*count[c]/nr_fold-i*count[c]/nr_fold;
			}
			fold_start[0]=0;
			for (i=1;i<=nr_fold;i++)
				fold_start[i] = fold_start[i-1]+fold_count[i-1];
			  //nr_class�����;nr_fold����
			for (c=0; c<nr_class;c++)
				for(i=0;i<nr_fold;i++)
				{
					int begin = start[c]+i*count[c]/nr_fold;
					int end = start[c]+(i+1)*count[c]/nr_fold;
					for(int j=begin;j<end;j++)
					{   //c��0��1ʱfold_start[i]�仯���
						perm[fold_start[i]] = index[j];
						fold_start[i]++;
					}
				}
			fold_start[0]=0;
			for (i=1;i<=nr_fold;i++)
				fold_start[i] = fold_start[i-1]+fold_count[i-1];
		}
		else
		{
			for(i=0;i<l;i++) perm[i]=i;
			for(i=0;i<l;i++)
			{
				int j = i+rand.nextInt(l-i);
				do {int _=perm[i]; perm[i]=perm[j]; perm[j]=_;} while(false);
			}
			for(i=0;i<=nr_fold;i++)
				fold_start[i]=i*l/nr_fold;
		}
		//����Ϊ������ֵ��ѡȡ������Ϊ��֤
		for(i=0;i<nr_fold;i++)
		{
			int begin = fold_start[i];
			int end = fold_start[i+1];
			int j,k;
			Data subprob = new Data();

			subprob.l = l-(end-begin);
			subprob.x = new Node[subprob.l][];
			subprob.y = new double[subprob.l];

			k=0;
			for(j=0;j<begin;j++)
			{
				subprob.x[k] = data.x[perm[j]];
				subprob.y[k] = data.y[perm[j]];
				++k;
			}
			for(j=end;j<l;j++)
			{
				subprob.x[k] = data.x[perm[j]];
				subprob.y[k] = data.y[perm[j]];
				++k;
			}
			Model submodel = svmTrain(subprob,param);
				for(j=begin;j<end;j++)
					target[perm[j]] = svmPredict(submodel,data.x[perm[j]]);
		}
	}

   /** ��ѵ���õ�ģ��Ԥ��������ֵ
	*@param model ģ��ϵ�����������ֵ
	*@param  x    ��ҪԤ�������
	*@param dec_values �õ�����Ҫ������Ԥ��ֵ*/
	public static double svmPredictValues(Model model, Node[] x, double[] dec_values)
	{
		int i;
		  //�ع飺��-SVR,��-SVR
		if(model.param.svmType == Parameter.EPSILON_SVR ||
		   model.param.svmType == Parameter.NU_SVR)
		{
			double[] sv_coef = model.svCoef[0];
			double sum = 0;
			for(i=0;i<model.svNumber;i++)
				sum += sv_coef[i] * Kernel.kFunction(x,model.SV[i],model.param);
			sum -= model.rho[0];
			dec_values[0] = sum;
			return sum;
		}
		else
		{
			int nr_class = model.categoryNumber;
			//l��������ĸ�����Ϊ֧�������ĸ���
			int l = model.svNumber;
		
			double[] kvalue = new double[l];
			for(i=0;i<l;i++)
				kvalue[i] = Kernel.kFunction(x,model.SV[i],model.param);

			int[] start = new int[nr_class];
			start[0] = 0;
			for(i=1;i<nr_class;i++)
				start[i] = start[i-1]+model.nSV[i-1];

			int[] vote = new int[nr_class];
			for(i=0;i<nr_class;i++)
				vote[i] = 0;

			int p=0;
			for(i=0;i<nr_class;i++)
				for(int j=i+1;j<nr_class;j++)
				{
					double sum = 0;
					int si = start[i];
					int sj = start[j];
					int ci = model.nSV[i];
					int cj = model.nSV[j];
				
					int k;
					double[] coef1 = model.svCoef[j-1];
					double[] coef2 = model.svCoef[i];
					for(k=0;k<ci;k++)
						sum += coef1[si+k] * kvalue[si+k];
					for(k=0;k<cj;k++)
						sum += coef2[sj+k] * kvalue[sj+k];
					sum -= model.rho[p];
					dec_values[p] = sum;					

					if(dec_values[p] > 0)
						++vote[i];
					else
						++vote[j];
					p++;
				}

			int vote_max_idx = 0;
			for(i=1;i<nr_class;i++)
				if(vote[i] > vote[vote_max_idx])
					vote_max_idx = i;

			return model.label[vote_max_idx];
		}
	}
   /**Ԥ��ĳһ������ֵ
    * @param model ģ��
    * @param x ��ҪԤ�������*/
	public static  double svmPredict(Model model, Node[] x)
	{
		int nr_class = model.categoryNumber;
		double[] dec_values;
		if(model.param.svmType == Parameter.EPSILON_SVR ||
				model.param.svmType == Parameter.NU_SVR)
			dec_values = new double[1];
		else
			dec_values = new double[nr_class*(nr_class-1)/2];
		double pred_result = svmPredictValues(model, x, dec_values);
		return pred_result;
	}

   /**�Ƿ��ڿ���̨�����*/
	public static void svmPrint(PrintInterface print)
	{
		if (print == null)
			svm_print_string = svm_print_stdout;
		else 
			svm_print_string = print;
	}
}
