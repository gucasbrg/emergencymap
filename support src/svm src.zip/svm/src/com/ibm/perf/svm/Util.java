package com.ibm.perf.svm;

import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.util.StringTokenizer;

import com.ibm.perf.parameter.Model;
import com.ibm.perf.parameter.Node;
import com.ibm.perf.parameter.Parameter;
import com.ibm.perf.parameter.Data;

/**��֤�����Ƿ���ʣ������ļ��Ȳ��������ڴ�����ʵ��*/
public class Util {
	static final String svmtype[] =
	{
		"c_svc","nu_svc","one_class","epsilon_svr","nu_svr",
	};

	static final String kerneltype[]=
	{
		"linear","polynomial","rbf","sigmoid","precomputed"
	};
    /**�õ�SVM����̬*/
	public static int getSvmType(Model model)
	{
		return model.param.svmType;
	}
   /**�õ����ݼ�������������뾭��ѵ���õ�ģ�ͺ�ſ����ã�*/
	public static int getClass(Model model)
	{
		return model.categoryNumber;
	}
   /**�õ����ݼ�������ţ����뾭��ѵ���õ�ģ�ͺ�ſ����ã�*/
	public static void getLabels(Model model, int[] label)
	{
		if (model.label != null)
			for(int i=0;i<model.categoryNumber;i++)
				label[i] = model.label[i];
	}
	/**�������Ĳ�������֤�����ѵ������������*/
	public static String checkParameter(Data data, Parameter param)
	{
		// svm_type
	
		int svm_type = param.svmType;
		if(svm_type != Parameter.C_SVC &&
		   svm_type != Parameter.NU_SVC &&
		   svm_type != Parameter.EPSILON_SVR &&
		   svm_type != Parameter.NU_SVR)
		return "unknown svm type";
	
		// kernel_type, degree
	
		int kernel_type = param.kernelType;
		if(kernel_type != Parameter.LINEAR &&
		   kernel_type != Parameter.POLY &&
		   kernel_type != Parameter.RBF &&
		   kernel_type != Parameter.SIGMOID)
			return "unknown kernel type";
	
		if(param.gamma < 0)
			return "gamma < 0";
	
		if(param.degree < 0)
			return "degree of polynomial kernel < 0";
	
		// cache_size,eps,C,nu,p,shrinking
	
		if(param.cacheSize <= 0)
			return "cache_size <= 0";
	
		if(param.stopCriteria <= 0)
			return "eps <= 0";
	
		if(svm_type == Parameter.C_SVC ||
		   svm_type == Parameter.EPSILON_SVR ||
		   svm_type == Parameter.NU_SVR)
			if(param.C <= 0)
				return "C <= 0";
	
		if(svm_type == Parameter.NU_SVC ||
		   svm_type == Parameter.NU_SVR)
			if(param.nu <= 0 || param.nu > 1)
				return "nu <= 0 or nu > 1";
	
		if(svm_type == Parameter.EPSILON_SVR)
			if(param.epsilon < 0)
				return "p < 0";
	
		if(param.shrinking != 0 &&
		   param.shrinking != 1)
			return "shrinking != 0 and shrinking != 1";

		// check whether nu-svc is feasible   
		//Training ��-Support Vector Classifiers: Theory and Algorithms #Lemma 1
	    //nr_class����	
		if(svm_type == Parameter.NU_SVC)
		{
			int l = data.l;
			int max_nr_class = 16;
			int nr_class = 0;
			int[] label = new int[max_nr_class];
			int[] count = new int[max_nr_class];
	
			int i;
			for(i=0;i<l;i++)
			{
				int this_label = (int)data.y[i];
				int j;
				for(j=0;j<nr_class;j++)
					if(this_label == label[j])
					{
						++count[j];
						break;
					}
	
				if(j == nr_class)
				{
					if(nr_class == max_nr_class)
					{
						max_nr_class *= 2;
						int[] new_data = new int[max_nr_class];
						System.arraycopy(label,0,new_data,0,label.length);
						label = new_data;
						
						new_data = new int[max_nr_class];
						System.arraycopy(count,0,new_data,0,count.length);
						count = new_data;
					}
					label[nr_class] = this_label;
					count[nr_class] = 1;
					++nr_class;
				}
			}
	
			for(i=0;i<nr_class;i++)
			{
				int n1 = count[i];
				for(int j=i+1;j<nr_class;j++)
				{
					int n2 = count[j];
					if(param.nu*(n1+n2)/2 > Math.min(n1,n2))
						return "specified nu is infeasible";
				}
			}
		}
	
		return null;
	}

	/**�÷�����model���浽�ļ���
	 * @param modelFile �ļ���
	 * @param model ģ��*/
	public static void saveModel(String modelFile, Model model) throws IOException
	{
		DataOutputStream fp = new DataOutputStream(new BufferedOutputStream(new FileOutputStream(modelFile)));
	
		Parameter param = model.param;
	
		fp.writeBytes("svm_type "+svmtype[param.svmType]+"\n");
		fp.writeBytes("kernel_type "+kerneltype[param.kernelType]+"\n");
	
		if(param.kernelType == Parameter.POLY)
			fp.writeBytes("degree "+param.degree+"\n");
	
		if(param.kernelType == Parameter.POLY ||
		   param.kernelType == Parameter.RBF ||
		   param.kernelType == Parameter.SIGMOID)
			fp.writeBytes("gamma "+param.gamma+"\n");
	
		if(param.kernelType == Parameter.POLY ||
		   param.kernelType == Parameter.SIGMOID)
			fp.writeBytes("coef0 "+param.r+"\n");
	
		int nr_class = model.categoryNumber;
		int l = model.svNumber;
		fp.writeBytes("nr_class "+nr_class+"\n");
		fp.writeBytes("total_sv "+l+"\n");
	
		{
			fp.writeBytes("rho");
			for(int i=0;i<nr_class*(nr_class-1)/2;i++)
				fp.writeBytes(" "+model.rho[i]);
			fp.writeBytes("\n");
		}
	
		if(model.label != null)
		{
			fp.writeBytes("label");
			for(int i=0;i<nr_class;i++)
				fp.writeBytes(" "+model.label[i]);
			fp.writeBytes("\n");
		}
	
		if(model.nSV != null)
		{
			fp.writeBytes("nr_sv");
			for(int i=0;i<nr_class;i++)
				fp.writeBytes(" "+model.nSV[i]);
			fp.writeBytes("\n");
		}
	
		fp.writeBytes("SV\n");
		double[][] sv_coef = model.svCoef;
		Node[][] SV = model.SV;
	
		for(int i=0;i<l;i++)
		{
			for(int j=0;j<nr_class-1;j++)
				fp.writeBytes(sv_coef[j][i]+" ");
	
			Node[] p = SV[i];	
				for(int j=0;j<p.length;j++)
					fp.writeBytes(p[j].index+":"+p[j].value+" ");
			fp.writeBytes("\n");
		}
	
		fp.close();
	}

	/**�÷�������һ��ѵ���õ�Model
	 * @param modelFile ģ���ļ���*/
	public static Model loadModel(String modelFile) throws IOException
	{
		return loadModel(new BufferedReader(new FileReader(modelFile)));
	}

	public static Model loadModel(BufferedReader fp) throws IOException
	{
		// read parameters
	
		Model model = new Model();
		Parameter param = new Parameter();
		model.param = param;
		model.rho = null;
		model.label = null;
		model.nSV = null;
	
		while(true)
		{
			String cmd = fp.readLine();
			String arg = cmd.substring(cmd.indexOf(' ')+1);
	
			if(cmd.startsWith("svm_type"))
			{
				int i;
				for(i=0;i<svmtype.length;i++)
				{
					if(arg.indexOf(svmtype[i])!=-1)
					{
						param.svmType=i;
						break;
					}
				}
				if(i == svmtype.length)
				{
					System.err.print("unknown svm type.\n");
					return null;
				}
			}
			else if(cmd.startsWith("kernel_type"))
			{
				int i;
				for(i=0;i<kerneltype.length;i++)
				{
					if(arg.indexOf(kerneltype[i])!=-1)
					{
						param.kernelType=i;
						break;
					}
				}
				if(i == kerneltype.length)
				{
					System.err.print("unknown kernel function.\n");
					return null;
				}
			}
			else if(cmd.startsWith("degree"))
				param.degree = atoi(arg);
			else if(cmd.startsWith("gamma"))
				param.gamma = atof(arg);
			else if(cmd.startsWith("coef0"))
				param.r = atof(arg);
			else if(cmd.startsWith("nr_class"))
				model.categoryNumber = atoi(arg);
			else if(cmd.startsWith("total_sv"))
				model.svNumber = atoi(arg);
			else if(cmd.startsWith("rho"))
			{
				int n = model.categoryNumber * (model.categoryNumber-1)/2;
				model.rho = new double[n];
				StringTokenizer st = new StringTokenizer(arg);
				for(int i=0;i<n;i++)
					model.rho[i] = atof(st.nextToken());
			}
			else if(cmd.startsWith("label"))
			{
				int n = model.categoryNumber;
				model.label = new int[n];
				StringTokenizer st = new StringTokenizer(arg);
				for(int i=0;i<n;i++)
					model.label[i] = atoi(st.nextToken());					
			}
			else if(cmd.startsWith("nr_sv"))
			{
				int n = model.categoryNumber;
				model.nSV = new int[n];
				StringTokenizer st = new StringTokenizer(arg);
				for(int i=0;i<n;i++)
					model.nSV[i] = atoi(st.nextToken());
			}
			else if(cmd.startsWith("SV"))
			{
				break;
			}
			else
			{
				System.err.print("unknown text in model file: ["+cmd+"]\n");
				return null;
			}
		}
	
		/** read sv_coef and SV*/
	
		int m = model.categoryNumber - 1;
		int l = model.svNumber;
		model.svCoef = new double[m][l];
		model.SV = new Node[l][];
	
		for(int i=0;i<l;i++)
		{
			String line = fp.readLine();
			StringTokenizer st = new StringTokenizer(line," \t\n\r\f:");
	
			for(int k=0;k<m;k++)
				model.svCoef[k][i] = atof(st.nextToken());
			//�����������쳣֮ǰ���Ե��ô� tokenizer �� nextToken �����Ĵ�����
			int n = st.countTokens()/2;
			model.SV[i] = new Node[n];
			for(int j=0;j<n;j++)
			{
				model.SV[i][j] = new Node();
				model.SV[i][j].index = atoi(st.nextToken());
				model.SV[i][j].value = atof(st.nextToken());
			}
		}
	
		fp.close();
		return model;
	}
	/**C��gamma����
	 * @param parameterFile �����ļ���
	 * @param gammaV ������*/
	public static void saveParameter(String parameterFile, double[] gammaV) throws IOException {
		DataOutputStream fp = new DataOutputStream(new BufferedOutputStream(new FileOutputStream(parameterFile)));		
			fp.writeBytes("C " + gammaV[0] + "\n");
			fp.writeBytes("gamma " + gammaV[1] + "\n");
			fp.close();
	}

     /**�ַ���תΪdouble����*/
	public static double atof(String s)
	{
		return Double.valueOf(s).doubleValue();
	}
    /**�ַ���ת��int����*/
	public static int atoi(String s)
	{
		return Integer.parseInt(s);
	}

}
