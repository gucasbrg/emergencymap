package com.ibm.perf.sol;

import com.ibm.perf.ker.Matrix;
import com.ibm.perf.svm.Predict;




/**���C-֧������������-֧�������ع���ⷨʵ��.  
 * <p>An SMO algorithm
<p>Solves:

	<p>&nbsp;&nbsp;min 0.5(<b>��</b><sup>T</sup>Q<b>��</b>) + <b>p</b><sup>T</sup><b>��</b>

	<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<b>y</b><sup>T</sup><b>��</b> = delta
	<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;y<sub>i</sub> = +1 or -1
	<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;0 <= ��<sub>i</sub> <= Cp for y<sub>i</sub> = 1
	<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;0 <= ��<sub>i</sub> <= Cn for y<sub>i</sub> = -1

<p>Given:

	<p><b>1</b>&nbsp;&nbsp;Q, p, y, Cp, Cn, and an initial feasible point alpha
	<p><b>2</b>&nbsp;&nbsp;l is the size of vectors and matrices
	<p><b>3</b>&nbsp;&nbsp;eps is the stopping tolerance

<p>solution will be put in alpha, objective value will be put in obj*/


public class Solver {
	/**����ʱʵ�ʲμ������������Ŀ������shrink �����󣬸���Ŀ��С��ȫ����������*/
	int active_size;  
	/**����������𣬸�ֵֻȡ+1/-1 ����Ȼ���Դ������࣬������������SVM��ɵ�*/
	byte[] y;         
	/**gradient of objective function��(Q�� + p)<sub>i</sub>*/
	double[] gra;		 
	/**��<sub>i</sub><=0*/
	static final byte LOWER_BOUND = 0;     
	/**��<sub>i</sub>=C*/
	static final byte UPPER_BOUND = 1;     
	/**0<��<sub>i</sub><C*/
	static final byte FREE = 2;    
	/**LOWER_BOUND, UPPER_BOUND, FREE*/
	byte[] alpha_status;	
	double[] alpha;
	Matrix Q;
	double[] QD;
	double eps; 
	double Cp,Cn;
	/**��׼�����е�p*/
	double[] p;
	int[] active_set;
	/**gradient, if we treat free variables as 0*/
	double[] G_bar;		
	/**��������*/
	int l;             
	boolean unshrink;	
	
	static final double INF = java.lang.Double.POSITIVE_INFINITY;

	double getC(int i)
	{
		return (y[i] > 0)? Cp : Cn;
	}
	void update_alpha_status(int i)
	{
		if(alpha[i] >= getC(i))
			alpha_status[i] = UPPER_BOUND;
		else if(alpha[i] <= 0)
			alpha_status[i] = LOWER_BOUND;
		else alpha_status[i] = FREE;
	}
	boolean isUpper_bound(int i) { return alpha_status[i] == UPPER_BOUND; }
	boolean isLower_bound(int i) { return alpha_status[i] == LOWER_BOUND; }
	boolean isFree(int i) {  return alpha_status[i] == FREE; }

	void swapIndex(int i, int j)
	{
		Q.swapIndex(i,j);
		do {byte _=y[i]; y[i]=y[j]; y[j]=_;} while(false);
		do {double _=gra[i]; gra[i]=gra[j]; gra[j]=_;} while(false);
		do {byte _=alpha_status[i]; alpha_status[i]=alpha_status[j]; alpha_status[j]=_;} while(false);
		do {double _=alpha[i]; alpha[i]=alpha[j]; alpha[j]=_;} while(false);
		do {double _=p[i]; p[i]=p[j]; p[j]=_;} while(false);
		do {int _=active_set[i]; active_set[i]=active_set[j]; active_set[j]=_;} while(false);
		do {double _=G_bar[i]; G_bar[i]=G_bar[j]; G_bar[j]=_;} while(false);
	}
	
	/**��˷��̵ĺ��ķ������õ����õĽ�������������еķ��������÷������� 
	 * @param l ��������
	 * @param Q �˾���
	 * @param p_ ��׼�����е�p
	 * @param y_ �����������
	 * @param alpha_ <b>��</b>
	 * @param Cp  0 <= ��<sub>i</sub> <= Cp for y<sub>i</sub> = 1
	 * @param Cn  0 <= ��<sub>i</sub> <= Cn for y<sub>i</sub> = -1
	 * @param eps ֹͣ����
	 * @param si  ����������Ϣ
	 * @param shrinking �Ƿ�ʹ������ʽ
	 * */
	void Solve(int l, Matrix Q, double[] p_, byte[] y_,
		   double[] alpha_, double Cp, double Cn, double eps, SolutionInfo si, int shrinking)
	{
		this.l = l;
		this.Q = Q;
		QD = Q.getQD();
		p = (double[])p_.clone();
		y = (byte[])y_.clone();
		alpha = (double[])alpha_.clone();
		this.Cp = Cp;
		this.Cn = Cn;
		this.eps = eps;
		this.unshrink = false;

		// ����һ��alpha ��״̬
		{
			alpha_status = new byte[l];
			for(int i=0;i<l;i++)
				update_alpha_status(i);
		}

		// initialize active set (for shrinking)
		{
			active_set = new int[l];
			for(int i=0;i<l;i++)
				active_set[i] = i;
			active_size = l;
		}

		// initialize gradient
		{
			gra = new double[l];
			G_bar = new double[l];
			int i;
			for(i=0;i<l;i++)
			{
				gra[i] = p[i];
				G_bar[i] = 0;
			}
			for(i=0;i<l;i++)
				//is_lower_bound alpha=0��������
				if(!isLower_bound(i))
				{
					float[] Q_i = Q.getQ(i,l);
					double alpha_i = alpha[i];
					int j;
					for(j=0;j<l;j++)
						gra[j] += alpha_i*Q_i[j];
					if(isUpper_bound(i))
						for(j=0;j<l;j++)
							G_bar[j] += getC(i) * Q_i[j];
				}
		}

		// optimization step

		int iter = 0;
		int max_iter = Math.max(10000000, l>Integer.MAX_VALUE/100 ? Integer.MAX_VALUE : 100*l);
		int counter = Math.min(l,1000)+1;
		int[] working_set = new int[2];   //ѡ��������������

		while(iter < max_iter)
		{
			// show progress and do shrinking

			if(--counter == 0)
			{
				counter = Math.min(l,1000);
				if(shrinking!=0) doShrinking();
				Predict.info(".");
			}

			if(selectWorkingSet(working_set)!=0)
			{
				// reconstruct the whole gradient
				reconstruct_gradient();
				// reset active set size and check
				active_size = l;
				Predict.info("*");
				if(selectWorkingSet(working_set)!=0)
					break;
				else
					counter = 1;	// do shrinking next iteration
			}
			
			int i = working_set[0];
			int j = working_set[1];

			++iter;

			// update alpha[i] and alpha[j], handle bounds carefully

			float[] Q_i = Q.getQ(i,active_size);
			float[] Q_j = Q.getQ(j,active_size);

			double C_i = getC(i);
			double C_j = getC(j);

			double old_alpha_i = alpha[i];
			double old_alpha_j = alpha[j];

			if(y[i]!=y[j])
			{
				double quad_coef = QD[i]+QD[j]+2*Q_i[j];
				if (quad_coef <= 0)
					quad_coef = 1e-12;
				double delta = (-gra[i]-gra[j])/quad_coef;
				double diff = alpha[i] - alpha[j];
				alpha[i] += delta;
				alpha[j] += delta;
			
				if(diff > 0)
				{
					if(alpha[j] < 0)
					{
						alpha[j] = 0;
						alpha[i] = diff;
					}
				}
				else
				{
					if(alpha[i] < 0)
					{
						alpha[i] = 0;
						alpha[j] = -diff;
					}
				}
				if(diff > C_i - C_j)
				{
					if(alpha[i] > C_i)
					{
						alpha[i] = C_i;
						alpha[j] = C_i - diff;
					}
				}
				else
				{
					if(alpha[j] > C_j)
					{
						alpha[j] = C_j;
						alpha[i] = C_j + diff;
					}
				}
			}
			else
			{
				double quad_coef = QD[i]+QD[j]-2*Q_i[j];
				if (quad_coef <= 0)
					quad_coef = 1e-12;
				double delta = (gra[i]-gra[j])/quad_coef;
				double sum = alpha[i] + alpha[j];
				alpha[i] -= delta;
				alpha[j] += delta;

				if(sum > C_i)
				{
					if(alpha[i] > C_i)
					{
						alpha[i] = C_i;
						alpha[j] = sum - C_i;
					}
				}
				else
				{
					if(alpha[j] < 0)
					{
						alpha[j] = 0;
						alpha[i] = sum;
					}
				}
				if(sum > C_j)
				{
					if(alpha[j] > C_j)
					{
						alpha[j] = C_j;
						alpha[i] = sum - C_j;
					}
				}
				else
				{
					if(alpha[i] < 0)
					{
						alpha[i] = 0;
						alpha[j] = sum;
					}
				}
			}

			// update G �����ݶ�

			double delta_alpha_i = alpha[i] - old_alpha_i;
			double delta_alpha_j = alpha[j] - old_alpha_j;

			for(int k=0;k<active_size;k++)
			{
				gra[k] += Q_i[k]*delta_alpha_i + Q_j[k]*delta_alpha_j;
			}

			// update alpha_status and G_bar

			{
				boolean ui = isUpper_bound(i);
				boolean uj = isUpper_bound(j);
				update_alpha_status(i);
				update_alpha_status(j);
				int k;
				if(ui != isUpper_bound(i))      //����alpha_i��Ӱ�죬ֻ��i��j�䶯
				{
					Q_i = Q.getQ(i,l);
					if(ui)
						for(k=0;k<l;k++)
							G_bar[k] -= C_i * Q_i[k];
					else
						for(k=0;k<l;k++)
							G_bar[k] += C_i * Q_i[k];
				}

				if(uj != isUpper_bound(j))     //����alpha_i��Ӱ��
				{
					Q_j = Q.getQ(j,l);
					if(uj)
						for(k=0;k<l;k++)
							G_bar[k] -= C_j * Q_j[k];
					else
						for(k=0;k<l;k++)
							G_bar[k] += C_j * Q_j[k];
				}
			}

		}
		
		if(iter >= max_iter)
		{
			if(active_size < l)
			{
				// reconstruct the whole gradient to calculate objective value
				reconstruct_gradient();
				active_size = l;
				Predict.info("*");
			}
			Predict.info("\nWARNING: �������ĵ�������");
		}

		// calculate rho

		si.rho = calculateRho();

		// ����Ŀ�꺯��ֵ
		{
			double v = 0;
			int i;
			for(i=0;i<l;i++)
				v += alpha[i] * (gra[i] + p[i]);   //G[i]=(Q�� + p)_i

			si.obj = v/2;
		}

		// put back the solution
		{
			for(int i=0;i<l;i++)
				alpha_[active_set[i]] = alpha[i];
		}

		si.upper_bound_p = Cp;
		si.upper_bound_n = Cn;

		Predict.info("\n�Ż����, �������� = "+iter+"\n");
	}
    /**������active_size���ݶ� */
	void reconstruct_gradient()
	{
		// reconstruct inactive elements of G from G_bar and free variables

		if(active_size == l) return;

		int i,j;
		int nr_free = 0;

		for(j=active_size;j<l;j++)
			gra[j] = G_bar[j] + p[j];

		for(j=0;j<active_size;j++)
			if(isFree(j))
				nr_free++;

		if(2*nr_free < active_size)
			Predict.info("\nWARNING: using -h 0 may be faster\n");

		if (nr_free*l > 2*active_size*(l-active_size))
		{
			for(i=active_size;i<l;i++)
			{
				float[] Q_i = Q.getQ(i,active_size);
				for(j=0;j<active_size;j++)
					if(isFree(j))
						gra[i] += alpha[j] * Q_i[j];
			}	
		}
		else
		{
			for(i=0;i<active_size;i++)
				if(isFree(i))
				{
					float[] Q_i = Q.getQ(i,l);
					double alpha_i = alpha[i];
					for(j=active_size;j<l;j++)
						gra[j] += alpha_i * Q_i[j];
				}
		}
	}
	
	/** return 1 if already optimal, return 0 otherwise*/
	int selectWorkingSet(int[] working_set)
	{   // return i,j such that
		//i=argmax({-G[t]|y[t]=1,alpha[t]<C},{G[t]|y[t]=-1,alpha[t]>0})
		// j: mimimizes the decrease of obj value
		//    (if quadratic coefficeint <= 0, replace it with tau)
		//    -y_j*grad(f)_j < -y_i*grad(f)_i, j in I_low(alpha)
		double Gmax = -INF;                         //Gmax\Gmax2������ֹ������֤
		double Gmax2 = -INF;               
		int Gmax_idx = -1;                          //Gmax_idx\Gmin_idx���й�����ѡ��
		int Gmin_idx = -1;
		double obj_diff_min = INF;
	
		for(int t=0;t<active_size;t++)
			if(y[t]==+1)	
			{
				if(!isUpper_bound(t))
					if(-gra[t] >= Gmax)
					{
						Gmax = -gra[t];
						Gmax_idx = t;
					}
			}
			else
			{
				if(!isLower_bound(t))
					if(gra[t] >= Gmax)
					{
						Gmax = gra[t];
						Gmax_idx = t;
					}
			}
	
		int i = Gmax_idx;
		float[] Q_i = null;
		if(i != -1) // null Q_i not accessed: Gmax=-INF if i=-1
			Q_i = Q.getQ(i,active_size);
	
		for(int j=0;j<active_size;j++)
		{
			if(y[j]==+1)
			{
				if (!isLower_bound(j))
				{
					double grad_diff=Gmax+gra[j];
					if (gra[j] >= Gmax2)
						Gmax2 = gra[j];
					//b_ts
					if (grad_diff > 0)
					{
						double obj_diff; 
						double quad_coef = QD[i]+QD[j]-2.0*y[i]*Q_i[j];
						if (quad_coef > 0)
							obj_diff = -(grad_diff*grad_diff)/quad_coef;
						else
							obj_diff = -(grad_diff*grad_diff)/1e-12;
	
						if (obj_diff <= obj_diff_min)
						{
							Gmin_idx=j;
							obj_diff_min = obj_diff;
						}
					}
				}
			}
			else
			{
				if (!isUpper_bound(j))
				{
					double grad_diff= Gmax-gra[j];
					if (-gra[j] >= Gmax2)
						Gmax2 = -gra[j];
					if (grad_diff > 0)
					{
						double obj_diff; 
						double quad_coef = QD[i]+QD[j]+2.0*y[i]*Q_i[j];
						if (quad_coef > 0)
							obj_diff = -(grad_diff*grad_diff)/quad_coef;
						else
							obj_diff = -(grad_diff*grad_diff)/1e-12;
	
						if (obj_diff <= obj_diff_min)
						{
							Gmin_idx=j;
							obj_diff_min = obj_diff;
						}
					}
				}
			}
		}

		if(Gmax+Gmax2 < eps)
			return 1;

		working_set[0] = Gmax_idx;
		working_set[1] = Gmin_idx;
		return 0;
	}
     /**���� Literature��A Library for Support Vector Machines2011��30��*/
	private boolean beShrunk(int i, double Gmax1, double Gmax2)
	{	
		if(isUpper_bound(i))
		{
			if(y[i]==+1)
				return(-gra[i] > Gmax1);
			else
				return(-gra[i] > Gmax2);
		}
		else if(isLower_bound(i))
		{
			if(y[i]==+1)
				return(gra[i] > Gmax2);
			else	
				return(gra[i] > Gmax1);
		}
		else
			return(false);
	}

	void doShrinking()
	{
		int i;
		double Gmax1 = -INF;		// max { -y_i * grad(f)_i | i in I_up(\alpha) }=m(alpha)=Gmax1
		double Gmax2 = -INF;		// max { y_i * grad(f)_i | i in I_low(\alpha) }=-M(alpha)=Gmax2

		// find maximal violating pair first
		for(i=0;i<active_size;i++)
		{
			if(y[i]==+1)
			{
				if(!isUpper_bound(i))	
				{
					if(-gra[i] >= Gmax1)
						Gmax1 = -gra[i];
				}
				if(!isLower_bound(i))
				{
					if(gra[i] >= Gmax2)
						Gmax2 = gra[i];
				}
			}
			else		
			{
				if(!isUpper_bound(i))	
				{
					if(-gra[i] >= Gmax2)
						Gmax2 = -gra[i];
				}
				if(!isLower_bound(i))	
				{
					if(gra[i] >= Gmax1)
						Gmax1 = gra[i];
				}
			}
		}

		if(unshrink == false && Gmax1 + Gmax2 <= eps*10) 
		{
			unshrink = true;
			reconstruct_gradient();
			active_size = l;
		}

		for(i=0;i<active_size;i++)
			if (beShrunk(i, Gmax1, Gmax2))
			{
				active_size--;   //�������һ��λ�����ã�active_size--
				while (active_size > i)
				{
					if (!beShrunk(active_size, Gmax1, Gmax2))
					{
						swapIndex(i,active_size);     //�����������������ǰ��
						break;
					}
					active_size--;
				}
			}
	}
    /**����Ѽ�-b*/
	double calculateRho()
	{
		double r;
		int nr_free = 0;
		double ub = INF, lb = -INF, sum_free = 0;
		for(int i=0;i<active_size;i++)
		{
			double yG = y[i]*gra[i];

			if(isLower_bound(i))
			{
				if(y[i] > 0)
					ub = Math.min(ub,yG);
				else
					lb = Math.max(lb,yG);
			}
			else if(isUpper_bound(i))
			{
				if(y[i] < 0)
					ub = Math.min(ub,yG);
				else
					lb = Math.max(lb,yG);
			}
			else
			{
				++nr_free;
				sum_free += yG;
			}
		}

		if(nr_free>0)
			r = sum_free/nr_free;
		else
			r = (ub+lb)/2;

		return r;
	}

}