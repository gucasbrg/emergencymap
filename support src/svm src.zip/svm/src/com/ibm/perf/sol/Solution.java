package com.ibm.perf.sol;

import com.ibm.perf.ker.SvcQ;
import com.ibm.perf.ker.SvrQ;
import com.ibm.perf.parameter.Parameter;
import com.ibm.perf.parameter.Data;
import com.ibm.perf.svm.Predict;

/**����������������ݣ���ѡ��Ĳ�����Ȼ���ö�Ӧģ�ͽ��д���*/
public class Solution {
	/**
	 * C-֧�����������
	 * 
	 * @param data  ���ݼ�
	 * @param param ����
	 * @param alpha <b>��</b>
	 * @param si    ��<b>��</b>������Ϣ
	 * @param Cp    ��<sub>i</sub>���Ͻ� for y<sub>i</sub> = 1
	 * @param Cn    ��<sub>i</sub>���Ͻ� for y<sub>i</sub> =-1
	 */
	public static void solveC_svc(Data data, Parameter param,double[] alpha, SolutionInfo si, double Cp, double Cn) {
		int l = data.l;	
		double[] minus_ones = new double[l];
		byte[] y = new byte[l];
		int i;
		for (i = 0; i < l; i++) {
			alpha[i] = 0;
			//minus_onesΪ(Q�� + p)�е�p
			minus_ones[i] = -1;
			if (data.y[i] > 0)
				y[i] = +1;
			else
				y[i] = -1;
		}
		Solver s = new Solver ();
		s.Solve(l, new SvcQ(data, param, y), minus_ones, y, alpha, Cp, Cn,param.stopCriteria, si, param.shrinking);
		double sum_alpha = 0;
		for (i = 0; i < l; i++)
			sum_alpha += alpha[i];
		if (Cp == Cn)
			//C-��֮��Ĺ�ϵ
			Predict.info("�� = " + sum_alpha / (Cp * data.l) + "\n");
		for (i = 0; i < l; i++)
			alpha[i] *= y[i];
	}
    /**��-֧�����������
     * @param data  ���ݼ�
	 * @param param ����
	 * @param alpha <b>��</b>
	 * @param si    ��<b>��</b>������Ϣ*/
	public static void solveNu_svc(Data data, Parameter param,double[] alpha, SolutionInfo si) {
		int i;
		int l = data.l;
		double nu = param.nu;
		byte[] y = new byte[l];
		for (i = 0; i < l; i++)
			if (data.y[i] > 0)
				y[i] = +1;
			else
				y[i] = -1;

		double sum_pos = nu * l / 2;
		double sum_neg = nu * l / 2;
		for (i = 0; i < l; i++)
			if (y[i] == +1) {
				alpha[i] = Math.min(1.0, sum_pos);
				sum_pos -= alpha[i];
			} else {
				alpha[i] = Math.min(1.0, sum_neg);
				sum_neg -= alpha[i];
			}
		double[] zeros = new double[l];
		for (i = 0; i < l; i++)
			zeros[i] = 0;
		SolverNu s = new SolverNu();
		s.Solve(l, new SvcQ(data, param, y), zeros, y, alpha, 1.0, 1.0,
				param.stopCriteria, si, param.shrinking);
		double r = si.r;
		Predict.info("C = " + 1 / r + "\n");
		for (i = 0; i < l; i++)
			alpha[i] *= y[i] / r;
		si.rho /= r;
		si.obj /= (r * r);
		si.upper_bound_p = 1 / r;
		si.upper_bound_n = 1 / r;
	}
  /**��-֧�������ع��
     * @param data  ���ݼ�
	 * @param param ����
	 * @param alpha <b>��</b>
	 * @param si    ��<b>��</b>������Ϣ
	 */
	public static void solveEpsilon_svr(Data data, Parameter param,double[] alpha,SolutionInfo si) {
		int l = data.l;
		double[] alpha2 = new double[2 * l];
		double[] linear_term = new double[2 * l];
		byte[] y = new byte[2 * l];
		int i;
		for (i = 0; i < l; i++) {
			alpha2[i] = 0;
			linear_term[i] = param.epsilon - data.y[i];
			y[i] = 1;
			alpha2[i + l] = 0;
			linear_term[i + l] = param.epsilon + data.y[i];
			y[i + l] = -1;
		}
		Solver s = new Solver();
		s.Solve(2 * l, new SvrQ(data, param), linear_term, y, alpha2, param.C,param.C, param.stopCriteria, si, param.shrinking);
		double sum_alpha = 0;
		for (i = 0; i < l; i++) {
			alpha[i] = alpha2[i] - alpha2[i + l];
			sum_alpha += Math.abs(alpha[i]);
		}
		Predict.info("nu = " + sum_alpha / (param.C * l) + "\n");
	}
    /**	��-֧�������ع��
     * @param data  ���ݼ�
	 * @param param ����
	 * @param alpha <b>��</b>
	 * @param si    ��<b>��</b>������Ϣ
	 */
	public static void solveNu_svr(Data data, Parameter param,double[] alpha, SolutionInfo si) {
		int l = data.l;
		double C = param.C;
		double[] alpha2 = new double[2 * l];
		double[] linear_term = new double[2 * l];
		byte[] y = new byte[2 * l];
		int i;
		double sum = C * param.nu * l / 2;
		for (i = 0; i < l; i++) {
			alpha2[i] = alpha2[i + l] = Math.min(sum, C);
			sum -= alpha2[i];
			linear_term[i] = -data.y[i];
			y[i] = 1;
			linear_term[i + l] = data.y[i];
			y[i + l] = -1;
		}

		SolverNu s = new SolverNu();
		s.Solve(2 * l, new SvrQ(data, param), linear_term, y, alpha2, C, C,param.stopCriteria, si, param.shrinking);
		Predict.info("epsilon = " + (-si.r) + "\n");
		for (i = 0; i < l; i++)
			alpha[i] = alpha2[i] - alpha2[i + l];
	}

}
