package com.ibm.perf.application;

import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.util.StringTokenizer;

import com.ibm.perf.parameter.Model;
import com.ibm.perf.parameter.Node;
import com.ibm.perf.parameter.Parameter;
import com.ibm.perf.svm.Predict;
import com.ibm.perf.svm.Util;



/**Ϊһ�������࣬���ڷ���������ǿ����ø��ݲ�������������������ȷ��;���ڻع�����ǿ�����������������ϵ����*/
public class Evaluate {
	private void checkParameter(String argv[]) throws IOException{
		
		int i, predict_probability=0;

		// parse options
		for(i=0;i<argv.length;i++)
		{
			if(argv[i].charAt(0) != '-') break;
			++i;
			switch(argv[i-1].charAt(1))
			{
				case 'b':
					predict_probability = Util.atoi(argv[i]);
					break;
				default:
					System.err.print("Unknown option: " + argv[i-1] + "\n");
					exitWithHelp();
			}
		}
		if(i>=argv.length-2)
			exitWithHelp();
		try 
		{
			BufferedReader input = new BufferedReader(new FileReader(argv[i])); //�����ļ�
			Model model = Util.loadModel(argv[i+1]);                       //ģ���ļ�
			DataOutputStream output = new DataOutputStream(new BufferedOutputStream(new FileOutputStream(argv[i+2])));//����ļ�

			predict(input,output,model,predict_probability);
			input.close();
			output.close();
		} 
		catch(FileNotFoundException e) 
		{
			exitWithHelp();
		}
		catch(ArrayIndexOutOfBoundsException e) 
		{
			exitWithHelp();
		}
	
	}
	private static void predict(BufferedReader input, DataOutputStream output, Model model, int predict_probability) throws IOException
	{
		int correct = 0;
		int total = 0;
		double error = 0;
		double sumv = 0, sumy = 0, sumvv = 0, sumyy = 0, sumvy = 0;

		int svm_type=Util.getSvmType(model);
		while(true)
		{
			String line = input.readLine();
			if(line == null) break;

			StringTokenizer st = new StringTokenizer(line," \t\n\r\f:");

			double target = Util.atof(st.nextToken());
			int m = st.countTokens()/2;
			Node[] x = new Node[m];
			for(int j=0;j<m;j++)
			{
				x[j] = new Node();
				x[j].index = Util.atoi(st.nextToken());
				x[j].value = Util.atof(st.nextToken());
			}

			double v;

			v = Predict.svmPredict(model,x);
			output.writeBytes(v+"\n");

			if(v == target)
				++correct;
			error += (v-target)*(v-target);
			sumv += v;
			sumy += target;
			sumvv += v*v;
			sumyy += target*target;
			sumvy += v*target;
			++total;
		}
		if(svm_type == Parameter.EPSILON_SVR ||
		   svm_type == Parameter.NU_SVR)
		{
			System.out.print("Mean squared error = "+error/total+" (regression)\n");
			System.out.print("Squared correlation coefficient = "+
				 ((total*sumvy-sumv*sumy)*(total*sumvy-sumv*sumy))/
				 ((total*sumvv-sumv*sumv)*(total*sumyy-sumy*sumy))+
				 " (regression)\n");
		}
		else
			System.out.print("Accuracy = "+(double)correct/total*100+
				 "% ("+correct+"/"+total+") (classification)\n");
	}

	private static void exitWithHelp()
	{
		System.err.print("usage: Predict [options] test_file model_file output_file\n"
		+"options:\n"
		+"-b probability_estimates: whether to predict probability estimates, 0 or 1 (default 0); one-class SVM not supported yet\n"
		+"��ʽ��-b probability_estimates �����ļ� ģ���ļ�  ����ļ�");
		System.exit(1);
	}

	public static void main(String argv[]) throws IOException 
	{
		Evaluate p=new Evaluate();
		p.checkParameter(argv);
	}
	
}
