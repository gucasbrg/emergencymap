package com.ibm.perf.application;

import java.awt.FileDialog;
import java.awt.Frame;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.util.StringTokenizer;
import java.util.Vector;

import com.ibm.perf.parameter.Model;
import com.ibm.perf.parameter.Node;
import com.ibm.perf.parameter.Parameter;
import com.ibm.perf.parameter.Data;
import com.ibm.perf.svm.Util;
import com.ibm.perf.svm.Predict;


/**�����������������ǿ��Եõ�ѵ��ģ�ͽ����Ȼ���ٶ�δ֪Ŀ��ֵ�����ݽ��д�ģ�͵Ļع�Ԥ�⣬�õ�Ŀ������֧�ָ�ά��������*/
public class RegressionPredict {
	private Parameter param = null;
	private Data prob;
	private Data prob_predict;
	private int sizeOfSearch = 11;
	private String error_msg;
	private Model model;
	private double maxcorrect = 0f;
	private String filename = null;
	private String filename_predict;
	

	public void init() {
		param = new Parameter();
		// default values
		param.svmType = Parameter.NU_SVR;
		param.kernelType = Parameter.RBF;
		param.degree = 3;
		param.gamma = 0; // 1/num_features
		param.r = 0;
		param.nu = 0.5;
		param.cacheSize = 100;
		param.C = 1;
		param.stopCriteria = 1e-3;
		param.epsilon = 0.1;
		param.shrinking = 1;
		param.nr_weight = 0;
		param.weight_label = new int[0];
		param.weight = new double[0];
	}
	/**
	 * format:
	 * <p><b>22</b> 1��0.5 2��23   .      
	 * <p><b>28</b> 1��0.4 2��22 
	 */

	public void loadTrain() throws IOException {
		FileDialog dialog = new FileDialog(new Frame(), "�򿪻ع�ѵ���ļ�", FileDialog.LOAD);
		dialog.setVisible(true);
		filename = dialog.getDirectory() + dialog.getFile();
		if (filename == null)
			return;
		BufferedReader fp = new BufferedReader(new FileReader(filename));
		Vector<Double> vy = new Vector<Double>();
		Vector<Node[]> vx = new Vector<Node[]>();
		int max_index = 0;

		while (true) // ѭ�������������ݣ�ÿ��ѭ�����һ����������źͶ�Ӧ����
		{
			String line = fp.readLine();
			if (line == null)
				break;

			StringTokenizer st = new StringTokenizer(line, " \t\n\r\f:");

			vy.addElement(Util.atof(st.nextToken()));
			int m = st.countTokens() / 2;
			Node[] x = new Node[m];
			for (int j = 0; j < m; j++) {
				x[j] = new Node();
				x[j].index = Util.atoi(st.nextToken());
				x[j].value = Util.atof(st.nextToken());
			}
			if (m > 0)
				max_index = Math.max(max_index, x[m - 1].index);
			vx.addElement(x);
		}

		prob = new Data();
		prob.l = vy.size();
		prob.x = new Node[prob.l][];
		for (int i = 0; i < prob.l; i++)
			prob.x[i] = vx.elementAt(i);
		prob.y = new double[prob.l];
		for (int i = 0; i < prob.l; i++)
			prob.y[i] = vy.elementAt(i);

		if (param.gamma == 0 && max_index > 0)
			param.gamma = 1.0 / max_index;
		fp.close();
	}
	/** format:
	 * <p>&nbsp;&nbsp;&nbsp;1��0.5 2��23 */
	public void loadPredict() throws IOException {
		FileDialog dialog = new FileDialog(new Frame(), "�򿪻ع�Ԥ���ļ�", FileDialog.LOAD);
		dialog.setVisible(true);
		filename_predict = dialog.getDirectory() + dialog.getFile();
		if (filename_predict == null)
			return;
		BufferedReader fp = new BufferedReader(new FileReader(filename_predict));
		Vector<Double> vy = new Vector<Double>();
		Vector<Node[]> vx = new Vector<Node[]>();

		while (true) // ѭ�������������ݣ�ÿ��ѭ�����һ����������źͶ�Ӧ����
		{
			String line = fp.readLine();
			if (line == null)
				break;

			StringTokenizer st = new StringTokenizer(line, " \t\n\r\f:");

			int m = st.countTokens() / 2;
			vy.addElement(0.0);
			Node[] x = new Node[m];
			for (int j = 0; j < m; j++) {
				x[j] = new Node();
				x[j].index = Util.atoi(st.nextToken());
				x[j].value = Util.atof(st.nextToken());
			}
			vx.addElement(x);
		}

		prob_predict = new Data();
		prob_predict.l = vx.size();
		prob_predict.x = new Node[prob_predict.l][];
		for (int i = 0; i < prob_predict.l; i++)
			{prob_predict.x[i] = vx.elementAt(i);
			}
		prob_predict.y = new double[prob_predict.l];
		for (int i = 0; i < prob_predict.l; i++)
			prob_predict.y[i] = vy.elementAt(i);
		fp.close();
	}

	public void grid(Data prob, Parameter param) {

		for (int c = 0; c < sizeOfSearch; c++) {
			// this is the power of the gamma parameter 2^g
			for (int g = 0; g < sizeOfSearch; g++) {
				int cVal = 2 * c - 5;
				int gVal = 2 * g - 5;
				double cost = Math.pow(2, cVal);
				double gamma = Math.pow(2, gVal);
				param.C = cost;
				param.gamma = gamma;
				double correct = 0f;
				correct = GridParameter.doCrossValidation(prob, param, 10);
				if (correct > maxcorrect) {
					maxcorrect = correct;
					param.C = cost;
					param.gamma = gamma;

				}
			}
		}
	}

	void savePredict() {
//		FileDialog dialog = new FileDialog(new Frame(), "����Ԥ���ļ�", FileDialog.SAVE);
//		dialog.setVisible(true);
		java.text.DecimalFormat  df=new  java.text.DecimalFormat("#0.00"); 
		String result_predict = filename_predict + ".predict";
		try {
			DataOutputStream fp = new DataOutputStream(
					new BufferedOutputStream(new FileOutputStream(
							result_predict)));
			for (int i = 0; i < prob_predict.l; i++) {
				fp.writeBytes(df.format(prob_predict.y[i]) + " ");
				for (int j = 0; j < prob_predict.x[i].length; j++) {
					fp.writeBytes(prob_predict.x[i][j].index + ":"+ prob_predict.x[i][j].value + " ");
				}
				fp.writeBytes("\n");
			}

			fp.close();
		} catch (IOException e) {
			System.err.print(e);
		}
	}

	public void  run() throws IOException {
		init();
		loadTrain();
		//grid(prob, param);�Ƿ������罻����֤��
		error_msg = Util.checkParameter(prob, param);

		if (error_msg != null) {
			System.err.print("ERROR: " + error_msg + "\n");
			System.exit(1);
		}

		model = Predict.svmTrain(prob, param); // �����������ݺͲ�������svm_train����ѵ��ģ��
		loadPredict();
		for (int i = 0; i < prob_predict.l; i++)
			prob_predict.y[i] = Predict.svmPredict(model, prob_predict.x[i]);
		
		savePredict();
		System.out.print("����ִ�н���");
	}
	public static void main(String[] argv) throws IOException
	{
		RegressionPredict p=new RegressionPredict();
		p.run();
	}
}