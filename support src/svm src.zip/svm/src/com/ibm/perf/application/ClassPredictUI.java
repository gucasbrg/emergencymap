package com.ibm.perf.application;

import java.util.StringTokenizer;
import java.util.Vector;
import java.io.BufferedOutputStream;
import java.io.DataOutputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.BufferedReader;
import java.io.IOException;


import com.ibm.perf.parameter.Data;
import com.ibm.perf.parameter.Model;
import com.ibm.perf.parameter.Node;
import com.ibm.perf.parameter.Parameter;
import com.ibm.perf.svm.Predict;
import com.ibm.perf.svm.Util;

import java.awt.Container;
import java.awt.BorderLayout;
import java.awt.FileDialog;
import java.awt.Frame;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;


import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;

       /**{@link ClassPredict}*/
public class ClassPredictUI {
	private JTextField trainingfile;
	private JButton checktrainingfile;
	private JButton gridsearch;
	private JButton buildmodel;
	private JTextField predictfile;
	private JButton checkpredictfile;
	private JButton predict;
	private JTextField savefile;
	private JButton savepredict;
	private static JTextArea text;

	private Parameter param = null;
	private Data prob = null;
	private Data prob_predict;
	private int sizeOfSearch = 11;
	private Model model;
	private double maxcorrect = 0f;

	private void createAndShowGUI() {
		JFrame.setDefaultLookAndFeelDecorated(true);

		JFrame frame = new JFrame("Class Predict");
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		Container con = frame.getContentPane();
		con.setLayout(new BorderLayout());

		JPanel jpup = new JPanel();
		jpup.setLayout(new GridLayout(4, 2));
		trainingfile = new JTextField(30);
		checktrainingfile = new JButton("Classified training file");
		checktrainingfile.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				FileDialog dialog = new FileDialog(new Frame(), "Load",FileDialog.LOAD);
				dialog.setVisible(true);
				String filename = dialog.getDirectory() + dialog.getFile();
				init();
				trainingfile.setText(filename);
				try {
					loadTrain(filename);
				} catch (IOException e1) {

					e1.printStackTrace();
				}
				predict.setEnabled(true);
			}
		}

		);
		gridsearch = new JButton("grid search");
		gridsearch.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (prob == null) {
					text.setText(text.getText()+ "Check Classified training file\n");
				} else {
					grid(prob, param);
					text.setText(text.getText()+ "the best parameter is finded \n");

				}
				predict.setEnabled(true);
			}
		});
		buildmodel = new JButton("build model");
		buildmodel.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (prob == null) {
					text.setText(text.getText()
							+ "Check Classified training file\n");
				} else {
					model = Predict.svmTrain(prob, param);
					text.setText(text.getText()
							+ "building model is finished \n");
				}
				predict.setEnabled(true);
			}
		});
		predictfile = new JTextField(30);
		checkpredictfile = new JButton("Classified predict file");
		checkpredictfile.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				FileDialog dialog = new FileDialog(new Frame(), "Load",FileDialog.LOAD);
				dialog.setVisible(true);
				String filename = dialog.getDirectory() + dialog.getFile();
				init();
				predictfile.setText(filename);
				try {
					loadPredict(filename);
				} catch (IOException e1) {

					e1.printStackTrace();
				}
				predict.setEnabled(true);
			}
		}

		);

		JLabel jl = new JLabel("");
		predict = new JButton("predict");
		predict.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (model == null) {
					text.setText(text.getText() + "Check model\n");
				} else {
					for (int i = 0; i < prob_predict.l; i++)
						prob_predict.y[i] = Predict.svmPredict(model,
								prob_predict.x[i]);
					for (int i = 0; i < prob_predict.l; i++) {
						text.setText(text.getText() + (int) prob_predict.y[i]
								+ " ");
						for (int j = 0; j < prob_predict.x[i].length; j++) {
							text.setText(text.getText()
									+ prob_predict.x[i][j].index + ":"
									+ prob_predict.x[i][j].value + " ");
						}
						text.setText(text.getText() + "\n");
					}

					System.out.print("Process ends");
				}
			}
		});
		jpup.add(trainingfile);
		jpup.add(checktrainingfile);
		jpup.add(gridsearch);
		jpup.add(buildmodel);
		jpup.add(predictfile);
		jpup.add(checkpredictfile);
		jpup.add(jl);
		jpup.add(predict);

		text = new JTextArea(10, 60);
		JScrollPane jsp = new JScrollPane(text);

		savepredict = new JButton("save file");
		savepredict.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				FileDialog dialog = new FileDialog(new Frame(), "Load",FileDialog.LOAD);
				dialog.setVisible(true);
				String filename = dialog.getDirectory() + dialog.getFile();
				savePredict(filename);
				predict.setEnabled(true);
			}
		});
		JPanel jpdown = new JPanel();
		jpdown.setLayout(new GridLayout(1, 2));
		savefile = new JTextField(30);
		jpdown.add(savefile);
		jpdown.add(savepredict);
		con.add(jpup, BorderLayout.NORTH);
		con.add(jsp, BorderLayout.CENTER);
		con.add(jpdown, BorderLayout.SOUTH);

		frame.setSize(200, 100);
		frame.pack();
		frame.setVisible(true);
	}

	public static void main(String[] args) {
		SwingUtilities.invokeLater(new Runnable() {
			public void run() {
				try {
					new ClassPredictUI().createAndShowGUI();
				} catch (Exception e) {
					JOptionPane.showMessageDialog(null, "�������ʧ�ܣ�");
				}
			}
		});
	}

	public void init() {
		param = new Parameter();
		// default values
		param.svmType = Parameter.C_SVC;
		param.kernelType = Parameter.RBF;
		param.degree = 3;
		param.gamma = 0; // 1/num_features
		param.r = 0;
		param.nu = 0.5;
		param.cacheSize = 100;
		param.C = 1;
		param.stopCriteria = 1e-3;
		param.epsilon = 0.1;
		param.shrinking = 1;
		param.nr_weight = 0;
		param.weight_label = new int[0];
		param.weight = new double[0];
	}

	public void loadTrain(String filename) throws IOException {
		BufferedReader fp = new BufferedReader(new FileReader(filename));
		Vector<Double> vy = new Vector<Double>();
		Vector<Node[]> vx = new Vector<Node[]>();
		int max_index = 0;

		while (true) // Loop characteristic data ,each cycle a feature of the
					// serial number and the corresponding data
		{
			String line = fp.readLine();
			if (line == null)
				break;

			StringTokenizer st = new StringTokenizer(line, " \t\n\r\f:");

			vy.addElement(Util.atof(st.nextToken()));
			int m = st.countTokens() / 2;
			Node[] x = new Node[m];
			for (int j = 0; j < m; j++) {
				x[j] = new Node();
				x[j].index = Util.atoi(st.nextToken());
				x[j].value = Util.atof(st.nextToken());
			}
			if (m > 0)
				max_index = Math.max(max_index, x[m - 1].index);
			vx.addElement(x);
		}

		prob = new Data();
		prob.l = vy.size();
		prob.x = new Node[prob.l][];
		for (int i = 0; i < prob.l; i++)
			prob.x[i] = vx.elementAt(i);
		prob.y = new double[prob.l];
		for (int i = 0; i < prob.l; i++)
			prob.y[i] = vy.elementAt(i);

		if (param.gamma == 0 && max_index > 0)
			param.gamma = 1.0 / max_index;
		fp.close();
	}

	public void grid(Data data, Parameter param) {

		for (int c = 0; c < sizeOfSearch; c++) {
			// this is the power of the gamma parameter 2^g
			for (int g = 0; g < sizeOfSearch; g++) {
				int cVal = 2 * c - 5;
				int gVal = 2 * g - 5;
				double cost = Math.pow(2, cVal);
				double gamma = Math.pow(2, gVal);
				param.C = cost;
				param.gamma = gamma;
				double correct = 0f;
				correct = GridParameter.doCrossValidation(prob, param, 10);
				if (correct > maxcorrect) {
					maxcorrect = correct;
					param.C = cost;
					param.gamma = gamma;

				}
			}
		}
	}

	public void loadPredict(String filename) throws IOException {
		BufferedReader fp = new BufferedReader(new FileReader(filename));
		Vector<Double> vy = new Vector<Double>();
		Vector<Node[]> vx = new Vector<Node[]>();

		while (true) // Loop characteristic data ,each cycle a feature of the
						// serial number and the corresponding data
		{
			String line = fp.readLine();
			if (line == null)
				break;

			StringTokenizer st = new StringTokenizer(line, " \t\n\r\f:");

			int m = st.countTokens() / 2;
			vy.addElement(0.0);
			Node[] x = new Node[m];
			for (int j = 0; j < m; j++) {
				x[j] = new Node();
				x[j].index = Util.atoi(st.nextToken());
				x[j].value = Util.atof(st.nextToken());
			}
			vx.addElement(x);
		}

		prob_predict = new Data();
		prob_predict.l = vx.size();
		prob_predict.x = new Node[prob_predict.l][];
		for (int i = 0; i < prob_predict.l; i++) {
			prob_predict.x[i] = vx.elementAt(i);
		}
		prob_predict.y = new double[prob_predict.l];
		for (int i = 0; i < prob_predict.l; i++)
			prob_predict.y[i] = vy.elementAt(i);
		fp.close();
	}

	void savePredict(String filename) {
		try {
			DataOutputStream fp = new DataOutputStream(new BufferedOutputStream(new FileOutputStream(filename)));
			for (int i = 0; i < prob_predict.l; i++) {
				fp.writeBytes((int) prob_predict.y[i] + " ");
				for (int j = 0; j < prob_predict.x[i].length; j++)
				{
					fp.writeBytes(prob_predict.x[i][j].index + ":"
							+ prob_predict.x[i][j].value + " ");
				}
				fp.writeBytes("\n");
			}

			fp.close();
		} catch (IOException e) {
			System.err.print(e);
		}
	}

}
