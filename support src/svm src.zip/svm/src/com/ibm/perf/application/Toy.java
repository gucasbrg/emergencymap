package com.ibm.perf.application;

import java.applet.Applet;


import java.awt.AWTEvent;
import java.awt.BorderLayout;
import java.awt.Button;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FileDialog;
import java.awt.Frame;
import java.awt.Graphics;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Image;
import java.awt.Panel;
import java.awt.TextField;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;


import java.util.StringTokenizer;
import java.util.Vector;

import com.ibm.perf.parameter.Model;
import com.ibm.perf.parameter.Node;
import com.ibm.perf.parameter.Parameter;
import com.ibm.perf.parameter.Data;
import com.ibm.perf.svm.Predict;




public class Toy extends Applet {
 
	private static final long serialVersionUID = -6772598456597111516L;
	static final String DEFAULT_PARAM="-t 2 -c 100";
	int XLEN;
	int YLEN;
	Parameter param=null;
	// off-screen buffer

	Image buffer;
	Graphics buffer_gc;

	// pre-allocated colors

	final static Color colors[] =
	{
	  new Color(0,0,0),
	  new Color(0,120,120),
	  new Color(120,120,0),
	  new Color(120,0,120),
	  new Color(0,200,200),
	  new Color(200,200,0),
	  new Color(200,0,200)
	};

	class point {
		point(double x, double y, byte value)
		{
			this.x = x;
			this.y = y;
			this.value = value;
		}
		double x, y;
		byte value;
	}

	Vector<point> point_list = new Vector<point>();
	byte current_value = 1;

	public void init()
	{
		setSize(getSize());

	    final Button button_change = new Button("Change");
		Button button_run = new Button("Run");
		Button button_clear = new Button("Clear");
		Button button_save = new Button("Save");
		Button button_load = new Button("Load");
		final TextField input_line = new TextField(DEFAULT_PARAM);

		BorderLayout layout = new BorderLayout();  //����û�м��Ĳ�����
		this.setLayout(layout);

		Panel p = new Panel();
		GridBagLayout gridbag = new GridBagLayout();
		p.setLayout(gridbag);

		GridBagConstraints c = new GridBagConstraints();
		c.fill = GridBagConstraints.HORIZONTAL; //��Ҫ��ť���ȳ�����Ԫ��
		c.weightx = 1;      //�е�Ȩ��
		c.gridwidth = 1;   //ռ��1����Ԫ�����
		gridbag.setConstraints(button_change,c);
		gridbag.setConstraints(button_run,c);
		gridbag.setConstraints(button_clear,c);
		gridbag.setConstraints(button_save,c);
		gridbag.setConstraints(button_load,c);
		c.weightx = 5;
		c.gridwidth = 5;
		gridbag.setConstraints(input_line,c);

		button_change.setBackground(colors[current_value]);

		p.add(button_change);
		p.add(button_run);
		p.add(button_clear);
		p.add(button_save);
		p.add(button_load);
		p.add(input_line);
		this.add(p,BorderLayout.SOUTH);

		button_change.addActionListener(new ActionListener()
		{ public void actionPerformed (ActionEvent e)
		  { buttonChangeClicked(); button_change.setBackground(colors[current_value]); }});

		button_run.addActionListener(new ActionListener()
		{ public void actionPerformed (ActionEvent e)
		  { buttonRunClicked(input_line.getText()); }});

		button_clear.addActionListener(new ActionListener()
		{ public void actionPerformed (ActionEvent e)
		  { buttonClearClicked(); }});

		button_save.addActionListener(new ActionListener()
		{ public void actionPerformed (ActionEvent e)
		  { buttonSaveClicked(); }});

		button_load.addActionListener(new ActionListener()
		{ public void actionPerformed (ActionEvent e)
		  { buttonLoadClicked(); }});

		input_line.addActionListener(new ActionListener()
		{ public void actionPerformed (ActionEvent e)
		  { buttonRunClicked(input_line.getText()); }});

		this.enableEvents(AWTEvent.MOUSE_EVENT_MASK);
	}

	void drawPoint(point p)
	{
		Color c = colors[p.value+3];

		Graphics window_gc = getGraphics();
		buffer_gc.setColor(c);
		buffer_gc.fillRect((int)(p.x*XLEN),(int)(p.y*YLEN),4,4);
		window_gc.setColor(c);
		window_gc.fillRect((int)(p.x*XLEN),(int)(p.y*YLEN),4,4);
	}

	void clearAll()
	{
		point_list.removeAllElements();
		if(buffer != null)
		{
			buffer_gc.setColor(colors[0]);
			buffer_gc.fillRect(0,0,XLEN,YLEN);
		}
		repaint();
	}

	void drawAllPoints()
	{
		int n = point_list.size();
		for(int i=0;i<n;i++)
			drawPoint(point_list.elementAt(i));
	}

	void buttonChangeClicked()
	{
		++current_value;
		if(current_value > 3) current_value = 1;
	}

	private static double atof(String s)
	{
		return Double.valueOf(s).doubleValue();
	}

	private static int atoi(String s)
	{
		return Integer.parseInt(s);
	}

	void buttonRunClicked(String args)
	{
		// guard
		if(point_list.isEmpty()) return;

		 param = new Parameter();

		// default values
		param.svmType = Parameter.C_SVC;
		param.kernelType = Parameter.RBF;
		param.degree = 3;
		param.gamma = 0;
		param.r = 0;
		param.nu = 0.5;
		param.cacheSize = 40;
		param.C = 1;
		param.stopCriteria = 1e-3;
		param.epsilon = 0.1;
		param.shrinking = 1;
		param.nr_weight = 0;
		param.weight_label = new int[0];
		param.weight = new double[0];

		// parse options
		StringTokenizer st = new StringTokenizer(args);
		String[] argv = new String[st.countTokens()];
		for(int i=0;i<argv.length;i++)
			argv[i] = st.nextToken();

		for(int i=0;i<argv.length;i++)
		{
			if(argv[i].charAt(0) != '-') break;
			if(++i>=argv.length)
			{
				System.err.print("unknown option\n");
				break;
			}
			switch(argv[i-1].charAt(1))
			{
				case 's':
					param.svmType = atoi(argv[i]);
					break;
				case 't':
					param.kernelType = atoi(argv[i]);
					break;
				case 'd':
					param.degree = atoi(argv[i]);
					break;
				case 'g':
					param.gamma = atof(argv[i]);
					break;
				case 'r':
					param.r = atof(argv[i]);
					break;
				case 'n':
					param.nu = atof(argv[i]);
					break;
				case 'm':
					param.cacheSize = atof(argv[i]);
					break;
				case 'c':
					param.C = atof(argv[i]);
					break;
				case 'e':
					param.stopCriteria = atof(argv[i]);
					break;
				case 'p':
					param.epsilon = atof(argv[i]);
					break;
				case 'h':
					param.shrinking = atoi(argv[i]);
					break;
				case 'w':
					++param.nr_weight;
					{
						int[] old = param.weight_label;
						param.weight_label = new int[param.nr_weight];
						System.arraycopy(old,0,param.weight_label,0,param.nr_weight-1);
					}

					{
						double[] old = param.weight;
						param.weight = new double[param.nr_weight];
						System.arraycopy(old,0,param.weight,0,param.nr_weight-1);
					}

					param.weight_label[param.nr_weight-1] = atoi(argv[i-1].substring(2));
					param.weight[param.nr_weight-1] = atof(argv[i]);
					break;
				default:
					System.err.print("unknown option\n");
			}
		}

		// build problem
		Data prob = new Data();
		prob.l = point_list.size();
		prob.y = new double[prob.l];

        if(param.svmType == Parameter.EPSILON_SVR ||
			param.svmType == Parameter.NU_SVR)
		{
			if(param.gamma == 0) param.gamma = 1;
			prob.x = new Node[prob.l][1];
			for(int i=0;i<prob.l;i++)
			{
				point p = point_list.elementAt(i);
				prob.x[i][0] = new Node();
				prob.x[i][0].index = 1;
				prob.x[i][0].value = p.x;
				prob.y[i] = p.y;
			}

			// build model & classify
			Model model = Predict.svmTrain(prob, param);
			Node[] x = new Node[1];
			x[0] = new Node();
			x[0].index = 1;
			int[] j = new int[XLEN];

			Graphics window_gc = getGraphics();
			for (int i = 0; i < XLEN; i++)
			{
				x[0].value = (double) i / XLEN;
				j[i] = (int)(YLEN*Predict.svmPredict(model, x));
			}
			
			buffer_gc.setColor(colors[0]);
			buffer_gc.drawLine(0,0,0,YLEN-1);
			window_gc.setColor(colors[0]);
			window_gc.drawLine(0,0,0,YLEN-1);
			
			int p = (int)(param.epsilon * YLEN);
			for(int i=1;i<XLEN;i++)
			{
				buffer_gc.setColor(colors[0]);
				buffer_gc.drawLine(i,0,i,YLEN-1);
				window_gc.setColor(colors[0]);
				window_gc.drawLine(i,0,i,YLEN-1);

				buffer_gc.setColor(colors[5]);
				window_gc.setColor(colors[5]);
				buffer_gc.drawLine(i-1,j[i-1],i,j[i]);
				window_gc.drawLine(i-1,j[i-1],i,j[i]);

				if(param.svmType == Parameter.EPSILON_SVR)
				{
					buffer_gc.setColor(colors[2]);
					window_gc.setColor(colors[2]);
					buffer_gc.drawLine(i-1,j[i-1]+p,i,j[i]+p);
					window_gc.drawLine(i-1,j[i-1]+p,i,j[i]+p);

					buffer_gc.setColor(colors[2]);
					window_gc.setColor(colors[2]);
					buffer_gc.drawLine(i-1,j[i-1]-p,i,j[i]-p);
					window_gc.drawLine(i-1,j[i-1]-p,i,j[i]-p);
				}
			}
		}
		else
		{
			if(param.gamma == 0) param.gamma = 0.5;
			prob.x = new Node [prob.l][2];
			for(int i=0;i<prob.l;i++)
			{
				point p = point_list.elementAt(i);
				prob.x[i][0] = new Node();
				prob.x[i][0].index = 1;
				prob.x[i][0].value = p.x;
				prob.x[i][1] = new Node();
				prob.x[i][1].index = 2;
				prob.x[i][1].value = p.y;
				prob.y[i] = p.value;
			}

			// build model & classify
			Model model = Predict.svmTrain(prob, param);
			Node[] x = new Node[2];
			x[0] = new Node();
			x[1] = new Node();
			x[0].index = 1;
			x[1].index = 2;

			Graphics window_gc = getGraphics();
			for (int i = 0; i < XLEN; i++)
				for (int j = 0; j < YLEN ; j++) {
					x[0].value = (double) i / XLEN;
					x[1].value = (double) j / YLEN;
					double d = Predict.svmPredict(model, x);
					buffer_gc.setColor(colors[(int)d]);
					window_gc.setColor(colors[(int)d]);
					buffer_gc.drawLine(i,j,i,j);
					window_gc.drawLine(i,j,i,j);
			}
		}

		drawAllPoints();
	}

	void buttonClearClicked()
	{
		clearAll();
	}

	void buttonSaveClicked()
	{
		FileDialog dialog = new FileDialog(new Frame(),"Save",FileDialog.SAVE);
		dialog.setVisible(true);
		String filename = dialog.getDirectory() + dialog.getFile();
		try {
			DataOutputStream fp = new DataOutputStream(new BufferedOutputStream(new FileOutputStream(filename)));
			int n = point_list.size();
			if (param.svmType == Parameter.EPSILON_SVR
					|| param.svmType == Parameter.NU_SVR) {
				for(int i=0;i<n;i++)
				{
					point p = point_list.elementAt(i);
					fp.writeBytes(p.y+" 1:"+p.x+"\n");
				}
			} else {
				for(int i=0;i<n;i++)
				{
					point p = point_list.elementAt(i);
					fp.writeBytes(p.value+" 1:"+p.x+" 2:"+p.y+"\n");
				}
			}
			
			fp.close();
		} catch (IOException e) { System.err.print(e); }
	}

	void buttonLoadClicked()
	{
		FileDialog dialog = new FileDialog(new Frame(),"Load",FileDialog.LOAD);
		dialog.setVisible(true);
		String filename = dialog.getDirectory() + dialog.getFile();
		clearAll();
		try {
			BufferedReader fp = new BufferedReader(new FileReader(filename));
			String line;
			while((line = fp.readLine()) != null)
			{
				StringTokenizer st = new StringTokenizer(line," \t\n\r\f:");
				if (3==st.countTokens()) {
					double y = atof(st.nextToken());
					st.nextToken();
					double x = atof(st.nextToken());
					point_list.addElement(new point(x,y,current_value));
				} else if (5==st.countTokens()) {
					byte value = (byte)atoi(st.nextToken());
					st.nextToken();
					double x = atof(st.nextToken());
					st.nextToken();
					double y = atof(st.nextToken());
					point_list.addElement(new point(x,y,value));
				}else{
					System.out.print("this file can't be loaded ");
				}
				
			}
			fp.close();
		} catch (IOException e) { System.err.print(e); }
		drawAllPoints();
	}
	
	protected void processMouseEvent(MouseEvent e)
	{
		if(e.getID() == MouseEvent.MOUSE_PRESSED)
		{
			if(e.getX() >= XLEN || e.getY() >= YLEN) return;
			point p = new point((double)e.getX()/XLEN,
					    (double)e.getY()/YLEN,
					    current_value);
			point_list.addElement(p);
			drawPoint(p);
		}
	}

	public void paint(Graphics g)
	{
		// create buffer first time
		if(buffer == null) {
			buffer = this.createImage(XLEN,YLEN);
			buffer_gc = buffer.getGraphics();
			buffer_gc.setColor(colors[0]);
			buffer_gc.fillRect(0,0,XLEN,YLEN);
		}
		g.drawImage(buffer,0,0,this);
	}

	public Dimension getPreferredSize() { return new Dimension(XLEN,YLEN+50); }

	public void setSize(Dimension d) 
	   { setSize(d.width,d.height); }
	public void setSize(int w,int h) {
		super.setSize(w,h);
		XLEN = w;
		YLEN = h-50;
		clearAll();
	}

	public static void main(String[] argv)
	{
		new AppletFrame("Toy",new Toy(),500,500+50);
	}
}

class AppletFrame extends Frame {
	private static final long serialVersionUID = -147304581535825029L;

	AppletFrame(String title, Applet applet, int width, int height)
	{
		super(title);
		this.addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowEvent e) {
				System.exit(0);
			}
		});
		applet.init();
		applet.setSize(width,height);
		applet.start();
		this.add(applet);
		this.pack();             //��������Զ�������С 
		this.setVisible(true);
	}
}
